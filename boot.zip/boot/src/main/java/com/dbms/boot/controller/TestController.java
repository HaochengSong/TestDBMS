package com.dbms.boot.controller;

import com.dbms.boot.domain.Country;
import com.dbms.boot.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;


@Controller
public class TestController {

    @Autowired
    private TestService service;

    @GetMapping("/hello")
    public String tt() {
//        model.addAttribute("say","欢迎欢迎,热烈欢迎");
//        map.put("hello", "欢迎进入HTML页面");
        return "index";
    }

    @GetMapping("/hello1")
    public String hello1() {
        return "table";
    }

}
