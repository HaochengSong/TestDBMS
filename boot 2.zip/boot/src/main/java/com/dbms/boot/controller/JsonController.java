package com.dbms.boot.controller;

import com.dbms.boot.object.Trend7;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JsonController {

    @GetMapping("/Trend7")
    public Trend7 getTrend7() {
        Trend7 trend7 = new Trend7();
        trend7.setYear(2020);
        trend7.setData1(1);
        trend7.setLabel1("l1");
        trend7.setData2(2);
        trend7.setLabel2("l2");
        trend7.setData3(3);
        trend7.setLabel3("l3");
        return trend7;
    }
}
