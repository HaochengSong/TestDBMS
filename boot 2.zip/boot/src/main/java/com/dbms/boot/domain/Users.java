package com.dbms.boot.domain;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Entity
@Data
public class Users {

    @Id
    private String USERNAME;

    @NotNull
    private String PASSWORD;
}
