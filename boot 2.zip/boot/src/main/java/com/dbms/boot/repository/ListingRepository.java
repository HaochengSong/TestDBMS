package com.dbms.boot.repository;

import com.dbms.boot.domain.Listing;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;

public interface ListingRepository extends JpaRepository<Listing, BigDecimal> {
}
