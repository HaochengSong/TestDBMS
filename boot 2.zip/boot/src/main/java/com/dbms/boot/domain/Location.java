package com.dbms.boot.domain;


import lombok.Data;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class Location {

//    @Id
//    private String RELIGION;
//
//    @Id
//    private String STATE;

    @EmbeddedId
    private LocationUPK locationUPK;

    private String LATITUDE;

    private String LONGITUDE;
}
