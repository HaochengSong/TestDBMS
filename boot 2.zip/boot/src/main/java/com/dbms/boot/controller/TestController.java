package com.dbms.boot.controller;

import com.dbms.boot.domain.Location;
import com.dbms.boot.domain.LocationUPK;
import com.dbms.boot.domain.Vehicle;
import com.dbms.boot.repository.ListingRepository;
import com.dbms.boot.repository.LocationRepository;
import com.dbms.boot.repository.ModelRepository;
import com.dbms.boot.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;


@Controller
public class TestController {

    @Autowired
    private ModelRepository modelRepository;

    @Autowired
    private ListingRepository listingRepository;

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    @GetMapping("/hello")
    public String t() {
        return "register";
    }

    @PostMapping("/welcome")
    public String tt(HttpServletRequest request, Model model) {
        String name = request.getParameter("username");
        String pass = request.getParameter("password");
        Vehicle vehicle = vehicleRepository.findById(name).orElse(null);
//        LocationUPK upk = new LocationUPK();
//        upk.setREGION("roanoke");
//        upk.setSTATE("va");
//        Location location = locationRepository.findById(upk).orElse(null);
        name = vehicle.getIMAGE_URL();
        pass = vehicleRepository.findManufacturer(vehicle.getVEHICLE_ID());
        if (name.equals(pass)) {
            name= "world";
        }
        model.addAttribute("message", name);
        model.addAttribute("message1", pass);
        return "index";
    }

    @GetMapping("/hello1")
    public String hello1(Model model) {
        model.addAttribute("message", "nihao");
        return "index";
    }

}
