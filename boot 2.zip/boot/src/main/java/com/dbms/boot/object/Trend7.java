package com.dbms.boot.object;

import lombok.Data;

@Data
public class Trend7 {

    private int year;

    private int data1;

    private String label1;

    private int data2;

    private String label2;

    private int data3;

    private String label3;
}
