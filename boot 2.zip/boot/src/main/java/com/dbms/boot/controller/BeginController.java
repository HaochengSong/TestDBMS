package com.dbms.boot.controller;

import com.dbms.boot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class BeginController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String getRegister(HttpServletRequest request) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean bo = userService.createUser(username, password);
        //注册成功返回初始网页
        if (bo) {

        }
        //重新注册， 返回注册网页
        else {

        }
        return null;
    }

    @PostMapping("/login")
    public String getLogin(HttpServletRequest request) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean bo = userService.login(username, password);
        //登陆成功返回首页
        if (bo) {

        }
        //登陆失败重新登陆，返回登陆页
        else {

        }
        return null;
    }
}
