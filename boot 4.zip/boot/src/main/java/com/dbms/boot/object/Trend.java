package com.dbms.boot.object;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Trend {

    private Integer year;

    private Integer data1;

    private String label1;

    private Integer data2;

    private String label2;

    private Integer data3;

    private String label3;

    private Integer data4;

    private String label4;

    public Trend() {
        super();
    }


    public Trend(Integer year, Integer data1, String label1, Integer data2, String label2) {
        this.year = year;
        this.data1 = data1;
        this.label1 = label1;
        this.data2 = data2;
        this.label2 = label2;
    }

    public Trend(Integer year, Integer data1, String label1) {
        this.year = year;
        this.data1 = data1;
        this.label1 = label1;
    }



    public Trend(Integer year, String label1, Integer data1, String label2, Integer data2, String label3, Integer data3) {
        this.year = year;
        this.data1 = data1;
        this.label1 = label1;
        this.data2 = data2;
        this.label2 = label2;
        this.data3 = data3;
        this.label3 = label3;
    }
}
