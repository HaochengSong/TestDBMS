package com.dbms.boot.repository;

import com.dbms.boot.domain.Location;
import com.dbms.boot.domain.LocationUPK;
import org.springframework.data.jpa.repository.JpaRepository;


public interface LocationRepository extends JpaRepository<Location, LocationUPK> {
}
