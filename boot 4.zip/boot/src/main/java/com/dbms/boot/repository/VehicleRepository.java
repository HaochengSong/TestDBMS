package com.dbms.boot.repository;

import com.dbms.boot.domain.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VehicleRepository extends JpaRepository<Vehicle, String> {

    @Query(nativeQuery = true, value = "SELECT DESIGNED_BY FROM liao.VEHICLE v, CARMODEL c\n" +
            "\nWHERE v.VEHICLE_ID = ?1 AND v.MODEL = c.MODEL_NAME")
    String findManufacturer(String vehicleID);
}
