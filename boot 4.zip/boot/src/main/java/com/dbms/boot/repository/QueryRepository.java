package com.dbms.boot.repository;

import com.dbms.boot.domain.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QueryRepository extends JpaRepository<Vehicle, String> {

    @Query(nativeQuery = true, value = "")
    List<Object[]> showSimple();

    @Query(nativeQuery = true, value = "SELECT DISTINCT t.avgprice, t2.numof, Listing.year\n" +
            "FROM LISTING,(SELECT AVG(liao.VEHICLE.price) as avgprice, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME\n" +
            "GROUP BY Listing.year) t, (SELECT COUNT(CARMODEL.transmission) as numof, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME AND CARMODEL.transmission = 'automatic' \n" +
            "GROUP BY Listing.year\n" +
            ") t2\n" +
            "WHERE  t.year = t2.year and t.year = Listing.year and Listing.year < 2020\n" +
            "ORDER BY LIsting.year DESC")
    List<Object[]> showComplex1();

    @Query(nativeQuery = true, value = "SELECT t.avgodo, t.year\n" +
            "FROM (SELECT AVG(liao.VEHICLE.odometer) as avgodo, LISTING.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME AND CARMODEL.CAR_SIZE = 'full-size'\n" +
            "GROUP BY Listing.year\n" +
            ") t \n" +
            "WHERE t.year< 2020\n" +
            "ORDER BY t.year DESC")
    List<Object[]> showComplex2();

    @Query(nativeQuery = true, value = "SELECT DISTINCT t4.kinds,t4.numsize, Listing.year\n" +
            "FROM \n" +
            "Listing, (SELECT t2.kinds,t2.numsize, t2.year\n" +
            "FROM (SELECT COUNT(*) as numsize, CARMODEL.CAR_SIZE as kinds, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME\n" +
            "GROUP BY CARMODEL.CAR_SIZE, Listing.year\n" +
            ") t2\n" +
            "WHERE t2.numsize >= ALL(SELECT t3.numsize FROM (SELECT COUNT(*) as numsize, CARMODEL.CAR_SIZE as kinds, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME\n" +
            "GROUP BY CARMODEL.CAR_SIZE, Listing.year\n" +
            ") t3 WHERE t3.year = t2.year )) t4\n" +
            "WHERE  Listing.year = t4.year and Listing.year > 1900 and Listing.year < 2020\n" +
            "ORDER BY LIsting.year DESC")
    List<Object[]> showComplex3();

    @Query(nativeQuery = true, value = "SELECT DISTINCT t.stats, t.year\n" +
            "FROM LISTING,\n" +
            "(SELECT COUNT(liao.VEHICLE.title_status) as stats, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE, CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME AND liao.VEHICLE.title_status = 'clean'\n" +
            "GROUP BY Listing.year\n" +
            ") t\n" +
            "WHERE  t.year < 2020\n" +
            "ORDER BY t.year DESC")
    List<Object[]> showComplex4();

    @Query(nativeQuery = true, value = "SELECT DISTINCT t.num, t.year\n" +
            "FROM LISTING,(SELECT COUNT(*) as num, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE,CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME AND CARMODEL.DESIGNED_BY = 'ram'\n" +
            "GROUP BY Listing.year\n" +
            ") t\n" +
            "WHERE  t.year < 2020\n" +
            "ORDER BY t.year DESC")
    List<Object[]> showComplex5();

    @Query(nativeQuery = true, value = "SELECT DISTINCT t.num, t.year\n" +
            "FROM LISTING,(SELECT COUNT(liao.VEHICLE.VEHICLE_ID) as num, Listing.year\n" +
            "FROM LISTING, liao.VEHICLE,CARMODEL\n" +
            "WHERE LISTING.CARID = liao.VEHICLE.VEHICLE_ID AND liao.VEHICLE.MODEL = CARMODEL.MODEL_NAME AND liao.VEHICLE.\"STATE\" = 'fl' AND liao.VEHICLE.region = 'treasure coast'\n" +
            "GROUP BY Listing.year\n" +
            ") t\n" +
            "WHERE  t.year < 2020\n" +
            "ORDER BY t.year DESC\n")
    List<Object[]> showComplex6();

    @Query(nativeQuery = true, value = "select *\n" +
            "from \n" +
            "(\n" +
            "    (\n" +
            "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
            "    from \n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R1,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R2,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R3\n" +
            "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
            "    )\n" +
            "    UNION\n" +
            "    (\n" +
            "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
            "    from \n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R1,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R2,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R3\n" +
            "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
            "    )\n" +
            "    UNION\n" +
            "    (\n" +
            "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
            "    from \n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R1,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R2,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R3\n" +
            "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
            "    )\n" +
            "    UNION\n" +
            "    (\n" +
            "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
            "    from \n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R1,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R2,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R3\n" +
            "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
            "    )\n" +
            "    UNION\n" +
            "    (\n" +
            "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
            "    from \n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R1,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R2,\n" +
            "        (\n" +
            "        select year, brand, sales, rownum as rn\n" +
            "        from (\n" +
            "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
            "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
            "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
            "            group by L.year, M.designed_by\n" +
            "            order by year, count(*) DESC\n" +
            "        )\n" +
            "        where rownum<=3\n" +
            "        ) R3\n" +
            "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
            "    )\n" +
            ")\n" +
            "\n")
    List<Object[]> showComplex7();



    @Query(nativeQuery = true, value = "select r1.year as year1, r1.state as stata1, r1.cnt as cnt1, r2.year as year2, r2.state as state2, r2.cnt as cnt2, r3.year as year3, r3.state as state3, r3.cnt as cnt3, r4.year as year4, r4.state as state4, r4.cnt as cnt4, r5.year as year5, r5.state as state5, r5.cnt as cnt5, r1.cnt + r2.cnt + r3.cnt + r4.cnt + r5.cnt as amount\n" +
            "from \n" +
            "(select year, state, cnt\n" +
            "from \n" +
            "(select year, state, cnt\n" +
            "from\n" +
            "(select l.year as year, v.state as state, count(l.carid) as cnt\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year = 2019\n" +
            "group by v.state, l.year)\n" +
            "where state in \n" +
            "(select state\n" +
            "from\n" +
            "(select v.state as state\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year >= 2015 and l.year <= 2019\n" +
            "group by v.state\n" +
            "order by count(l.carid) desc) t1\n" +
            "where rownum < 6)) t4) r1,\n" +
            "(select year, state, cnt\n" +
            "from \n" +
            "(select t3.year, t3.state, t3.cnt\n" +
            "from\n" +
            "(select l.year as year, v.state as state, count(l.carid) as cnt\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year = 2018\n" +
            "group by v.state, l.year) t3\n" +
            "where t3.state in \n" +
            "(select state\n" +
            "from\n" +
            "(select v.state as state\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year >= 2015 and l.year <= 2019\n" +
            "group by v.state\n" +
            "order by count(l.carid) desc) t1\n" +
            "where rownum < 11)) t4) r2,\n" +
            "(select year, state, cnt\n" +
            "from \n" +
            "(select t3.year, t3.state, t3.cnt\n" +
            "from\n" +
            "(select l.year as year, v.state as state, count(l.carid) as cnt\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year = 2017\n" +
            "group by v.state, l.year) t3\n" +
            "where t3.state in \n" +
            "(select state\n" +
            "from\n" +
            "(select v.state as state\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year >= 2015 and l.year <= 2019\n" +
            "group by v.state\n" +
            "order by count(l.carid) desc) t1\n" +
            "where rownum < 11)) t4) r3,\n" +
            "(select year, state, cnt\n" +
            "from \n" +
            "(select t3.year, t3.state, t3.cnt\n" +
            "from\n" +
            "(select l.year as year, v.state as state, count(l.carid) as cnt\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year = 2016\n" +
            "group by v.state, l.year) t3\n" +
            "where t3.state in \n" +
            "(select state\n" +
            "from\n" +
            "(select v.state as state\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year >= 2015 and l.year <= 2019\n" +
            "group by v.state\n" +
            "order by count(l.carid) desc) t1\n" +
            "where rownum < 11)) t4) r4,\n" +
            "(select year, state, cnt\n" +
            "from \n" +
            "(select t3.year, t3.state, t3.cnt\n" +
            "from\n" +
            "(select l.year as year, v.state as state, count(l.carid) as cnt\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year = 2015\n" +
            "group by v.state, l.year) t3\n" +
            "where t3.state in \n" +
            "(select state\n" +
            "from\n" +
            "(select v.state as state\n" +
            "from Listing l, liao.Vehicle v \n" +
            "where l.carid = v.vehicle_id and l.year >= 2015 and l.year <= 2019\n" +
            "group by v.state\n" +
            "order by count(l.carid) desc) t1\n" +
            "where rownum < 11)) t4) r5\n" +
            "where r1.state = r2.state and r2.state = r3.state and r3.state = r4.state and r4.state = r5.state")
    List<Object[]> showComplex8();
}
