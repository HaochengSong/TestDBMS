package com.dbms.boot.object;

import lombok.Data;

@Data
public class Trend8 {
    private Integer year;

    private Integer data1;

    private String label1;

    private Integer data2;

    private String label2;

    private Integer data3;

    private String label3;
}
