package com.dbms.boot.repository;

import com.dbms.boot.domain.Listing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface ListingRepository extends JpaRepository<Listing, BigDecimal> {

    @Query(nativeQuery = true,
            value = "select *\n" +
                    "from \n" +
                    "(\n" +
                    "    (\n" +
                    "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
                    "    from \n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R1,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R2,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2015\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R3\n" +
                    "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
                    "    )\n" +
                    "    UNION\n" +
                    "    (\n" +
                    "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
                    "    from \n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R1,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R2,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2016\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R3\n" +
                    "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
                    "    )\n" +
                    "    UNION\n" +
                    "    (\n" +
                    "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
                    "    from \n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R1,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R2,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2017\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R3\n" +
                    "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
                    "    )\n" +
                    "    UNION\n" +
                    "    (\n" +
                    "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
                    "    from \n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R1,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R2,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2018\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R3\n" +
                    "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3\n" +
                    "    )\n" +
                    "    UNION\n" +
                    "    (\n" +
                    "    select R1.year, R1.brand as brand1, R1.sales as sales1, R2.brand as brand2, R2.sales as sales2, R3.brand as brand3, R3.sales as sales3\n" +
                    "    from \n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R1,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R2,\n" +
                    "        (\n" +
                    "        select year, brand, sales, rownum as rn\n" +
                    "        from (\n" +
                    "            select L.year as year, M.designed_by as brand, count(*) as sales\n" +
                    "            from Listing L, liao.Vehicle V, CARMODEL M\n" +
                    "            where L.carID = V.vehicle_id and M.model_name = V.model and year = 2019\n" +
                    "            group by L.year, M.designed_by\n" +
                    "            order by year, count(*) DESC\n" +
                    "        )\n" +
                    "        where rownum<=3\n" +
                    "        ) R3\n" +
                    "    where R1.year = R2.year and R2.year = R3.year and R1.rn = 1 and R2.rn = 2 and R3.rn = 3))")
    List<Object[]> showComplex7();
}
