package com.dbms.boot.controller;

import com.dbms.boot.object.Trend;
import com.dbms.boot.repository.ListingRepository;
import com.dbms.boot.repository.QueryRepository;
import com.dbms.boot.utils.EntityUtils;
import com.sun.tools.corba.se.idl.InterfaceGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.management.Query;
import java.lang.reflect.Constructor;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class JsonController {

    @Autowired
    private ListingRepository listingRepository;

    @Autowired
    private QueryRepository queryRepository;

    private Integer bigToInteger(BigDecimal b) {
        if (b == null)
            return null;
        return b.intValue();
    }

    @GetMapping("/Trend1")
    public List<Trend> getTrend1() {
        List<Object[]> objects = queryRepository.showComplex1();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[2]), bigToInteger((BigDecimal) o[0]), "Average Price", bigToInteger((BigDecimal) o[1]), "Number")
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend2")
    public List<Trend> getTrend2() {
        List<Object[]> objects = queryRepository.showComplex2();
        System.out.println(objects.size());
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[1]), bigToInteger((BigDecimal) o[0]), "Average odometer")
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend3")
    public List<Trend> getTrend3() {
        List<Object[]> objects = queryRepository.showComplex3();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[2]), bigToInteger((BigDecimal) o[1]), (String) o[0])
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend4")
    public List<Trend> getTrend4() {
        List<Object[]> objects = queryRepository.showComplex4();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[1]), bigToInteger((BigDecimal) o[0]), "Status")
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend5")
    public List<Trend> getTrend5() {
        List<Object[]> objects = queryRepository.showComplex5();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[1]), bigToInteger((BigDecimal) o[0]), "Number of Used Car")
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend6")
    public List<Trend> getTrend6() {
        List<Object[]> objects = queryRepository.showComplex6();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[1]), bigToInteger((BigDecimal) o[0]), "Number of Used Car")
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend7")
    public List<Trend> getTrend7() {
        List<Object[]> objects = queryRepository.showComplex7();
        List<Trend> list = objects.stream().map(
                o -> new Trend(bigToInteger((BigDecimal) o[0]), (String) o[1], bigToInteger((BigDecimal) o[2]), (String) o[3], bigToInteger((BigDecimal) o[4]), (String) o[5], bigToInteger((BigDecimal) o[6]))
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        BigDecimal tmp = new BigDecimal(50);
        int tmp2 = tmp.intValue();
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/Trend8")
    public List<Trend> getTrend8() {
        List<Object[]> objects = queryRepository.showComplex8();
        List<Trend> list = objects.stream().map(
                o -> new Trend(((BigDecimal) o[0]).intValue(), (String) o[1], ((BigDecimal) o[2]).intValue(), (String) o[3], ((BigDecimal) o[4]).intValue(), (String) o[5], ((BigDecimal) o[6]).intValue())
        ).collect(Collectors.toList());
//        System.out.println(objects.size());
//        List<Trend7> list = EntityUtils.castEntity(objects, Trend7.class, new Trend7());
        BigDecimal tmp = new BigDecimal(50);
        int tmp2 = tmp.intValue();
        System.out.println(list.size());
        return list;
    }

    @GetMapping("/TestTrend")
    public void testAllTrendNumber() {
//        List<Object[]> list1 = queryRepository.showComplex1();
//        System.out.println("list1 size is" + list1.size());
//        List<Object[]> list2 = queryRepository.showComplex2();
//        System.out.println("list2 size is" + list2.size());
//        List<Object[]> list3 = queryRepository.showComplex3();
//        System.out.println("list3 size is" + list3.size());
        List<Object[]> list4 = queryRepository.showComplex4();
        System.out.println("list4 size is" + list4.size());
        List<Object[]> list5 = queryRepository.showComplex5();
        System.out.println("list5 size is" + list5.size());
        List<Object[]> list6 = queryRepository.showComplex6();
        System.out.println("list6 size is" + list6.size());
        List<Object[]> list7 = queryRepository.showComplex7();
        System.out.println("list7 size is" + list7.size());
        List<Object[]> list8 = queryRepository.showComplex8();
        System.out.println("list8 size is" + list8.size());
    }
}
