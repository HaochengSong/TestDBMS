package com.dbms.boot.repository;

import com.dbms.boot.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;

public interface ReviewRepository extends JpaRepository<Review, BigDecimal> {
}
